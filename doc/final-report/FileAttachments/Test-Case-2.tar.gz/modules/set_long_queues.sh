#!/bin/bash

# require sudo

function showValues() {
	echo "gc_thresh1"
	cat /proc/sys/net/ipv4/neigh/default/gc_thresh1
	echo "gc_thresh2"
	cat /proc/sys/net/ipv4/neigh/default/gc_thresh2
	echo "gc_thresh3"
	cat /proc/sys/net/ipv4/neigh/default/gc_thresh3
	sysctl net.core.rmem_max
	sysctl net.core.wmem_max
	sysctl net.ipv4.udp_rmem_min
	sysctl net.ipv4.udp_wmem_min
	sysctl net.core.netdev_max_backlog
}

echo "Current values: "
showValues

echo 1024 > /proc/sys/net/ipv4/neigh/default/gc_thresh1
echo 2048 > /proc/sys/net/ipv4/neigh/default/gc_thresh2
echo 4096 > /proc/sys/net/ipv4/neigh/default/gc_thresh3
sysctl -w net.core.rmem_max=8388608
sysctl -w net.core.wmem_max=8388608
#sysctl -w net.ipv4.udp_rmem_min=131072
#sysctl -w net.ipv4.udp_wmem_min=131072
#sysctl -w net.core.netdev_max_backlog=2000

echo "New values:"
showValues

