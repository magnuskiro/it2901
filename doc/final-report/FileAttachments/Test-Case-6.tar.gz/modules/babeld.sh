#!/bin/bash


# Starts babeld routing daemon. Untested.

NODEID=$nodeid

if [ "$1" == "start" ]; then
	echo "Starting babeld"
	ip -6 route add ff02::/32 dev eth0
	ip -6 route add ff02::cca6:c0f9:e182:5373 dev eth0

	rm -f babel_node$NODEID.pid
	babeld eth0 -S babel_node$NODEID.state -I babel_node$NODEID.pid -L babel_node$NODEID.log -D -w
elif [ "$1" == "stop" ]; then
	echo "Stopping babeld"
	kill -INT `cat babel_node$NODEID.pid`
fi


