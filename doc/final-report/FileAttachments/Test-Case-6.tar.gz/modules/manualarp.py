#!/usr/bin/env python

import sys,os,subprocess

if len(sys.argv) < 2:
	print "usage:",sys.argv[0]," [start/stop]"
	exit(1)

if sys.argv[1] == "start":
	print "Adding manual ARP addresses to enable broadcast"
	total_nodes = int(os.getenv('total_nodes'))
	arp_mac = os.getenv('arp_mac')
	arp_ip = os.getenv('arp_ip')
	node_id = int(os.getenv('node_id'))

	for n in range(1,total_nodes+1):
		if n == node_id: # skip our own address
			continue
		mac = arp_mac % n
		ip = arp_ip % n
		#print "arp -s",ip,mac
		subprocess.call(["/usr/sbin/arp -s " + ip + " " + mac], shell=True)

	#subprocess.call(["/usr/sbin/arp -n"],shell=True)	
