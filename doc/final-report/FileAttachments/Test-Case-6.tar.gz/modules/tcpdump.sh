#!/bin/bash

PID_FILE=tcpdump_node${node_id}.pid

# resolve any shell variables
filter=`eval echo $filter`

if [ "$1" == "start" ]; then
	echo "Starting tcpdump with filter $filter on device $device"
	tcpdump -ni $device -w node${node_id}_eth0.pcap $filter &
	echo $! > $PID_FILE
elif [ "$1" == "stop" ]; then
	echo "Stopping tcpdump"
	kill -INT `cat $PID_FILE`
	rm -f $PID_FILE
else
	echo "invalid command"
fi
