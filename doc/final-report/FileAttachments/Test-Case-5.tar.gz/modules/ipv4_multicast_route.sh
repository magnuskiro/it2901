#!/bin/bash

if [ "$1" == "start" ]; then
	echo "Adding multicast route for 224.0.0.0 to device $device"
	route add -net 224.0.0.0 netmask 240.0.0.0 dev $device
	exit 0
	#route -n
fi
