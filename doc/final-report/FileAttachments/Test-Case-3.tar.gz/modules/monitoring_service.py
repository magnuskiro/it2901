#!/usr/bin/env python

from os import getenv
import re

node_id = int(getenv('node_id'))
if node_id == 1:
	path = '/home/qos/server/mobiemu/system-test-2/experiments/esb/'
	to_write = """<?xml version="1.0" encoding="UTF-8" ?>
	<config>
		<RoutingInfos>
			<RoutingInfo>
				<destIP>10.0.0.2</destIP>
				<lastTR>bob</lastTR>
				<bandwidth>{bandwidth}</bandwidth>
			</RoutingInfo>
			<RoutingInfo>
				<destIP>10.0.0.3</destIP>
				<lastTR>bob</lastTR>
				<bandwidth>{bandwidth}</bandwidth>
			</RoutingInfo>
			<RoutingInfo>
				<destIP>10.0.0.4</destIP>
				<lastTR>bob</lastTR>
				<bandwidth>{bandwidth}</bandwidth>
			</RoutingInfo>
		</RoutingInfos>
	</config>
	"""
	data_rate = re.match(r"[0-9]+(?=KBps)", getenv('datarate')).group(0)
	with open('{0}ms.xml'.format(path), 'w') as d:
		d.write(to_write.replace('{bandwidth}', str(data_rate)))
	print 'Wrote new ms.xml with bandwidth: ' + str(data_rate)
