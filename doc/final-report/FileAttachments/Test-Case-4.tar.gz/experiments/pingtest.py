#!/usr/bin/env python

import os,sys,subprocess

node_id = int(os.getenv('node_id'))
total_nodes = int(os.getenv('total_nodes'))

processes = [None] * total_nodes

# spawn one ping per node (except ourself)
for n in range(1,total_nodes+1):
	if (n != node_id):
		print "Starting ping from node ",node_id," to node ",n
		processes[n-1] = subprocess.Popen(["ping","-i","2","10.0.0."+str(n)])

# wait for all childs to exit
for n in range(0,total_nodes):
	if processes[n] != None:
		processes[n].wait()

print "pingtest.py exiting..."
