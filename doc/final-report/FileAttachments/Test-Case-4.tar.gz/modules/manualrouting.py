#!/usr/bin/env python

from subprocess import Popen
from os import getenv

#Popen(['route', 'add', '-net', '10.0.0.0', 'netmask', '10.0.0.255', 'gw', 'dev', 'eth0'])
node_id = int(getenv('node_id'))
if node_id != 2:
	print 'Adding default route'
	Popen(['route', 'add', 'default', 'gw', '10.0.0.2'])
else:
	print 'Adding forwarding on router'
	Popen(['route', 'add', '-net', '10.0.0.0', 'netmask', '255.255.255.0', 'gw', 'eth0'])
